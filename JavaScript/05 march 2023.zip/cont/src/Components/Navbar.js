import React from "react";

const Navbar = () => {
  return <h1>I am Navigation</h1>;
};

export default Navbar;
